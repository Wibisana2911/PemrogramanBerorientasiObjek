import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Boom here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Boom extends Actor
{
    public Boom(){
        GreenfootImage boomImage = getImage();
        int boomWidth = boomImage.getWidth()/6;
        int boomHeight = boomImage.getHeight()/6;
        boomImage.scale(boomWidth, boomHeight);
    }
    
    /**
     * Act - do whatever the Boom wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act(){
        // Add your action code here.
        turn(2);
        boom();
    }
    int boomTimer = 0;
    
    public void boom()
    {
        if (boomTimer==60){ //60fps = 1 detik
            getWorld().removeObject(this);
    }else{
        boomTimer++;
    }
    }
}
    
    