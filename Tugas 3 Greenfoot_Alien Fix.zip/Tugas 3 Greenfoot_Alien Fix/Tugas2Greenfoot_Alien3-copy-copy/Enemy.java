import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Enemy here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

/**
     * Act - do whatever the Enemy wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
public class Enemy extends Actor
{
    public Enemy(){
        setRotation(180);
        GreenfootImage enemyImage = getImage();
        int enemyWidth = enemyImage.getWidth()/6;
        int enemyHeight = enemyImage.getHeight()/6;
        enemyImage.scale(enemyWidth, enemyHeight);
        enemyImage.mirrorVertically();
    }
    
    public Enemy (int speed)
    {
        setRotation(180);
        this.speed = speed;
    }
        public int speed = 3;
        
    public void removeEnemy()
    {
        //move(speed);
        if (isAtEdge()){
            getWorld().removeObject(this);
        }
    }
    
    public void act() //60 per detik
    {
        // Add your action code here.
        //setRotation(180);
        move(speed);
        removeEnemy();       
        shootLaser();
    }
        int laserTimer = 0;
    
    public void shootLaser(){
        if (laserTimer == 120){
            getWorld().addObject(
            new LaserEnemy(),
            getX() - 60,
            getY()
            );
            laserTimer = 0;
        }else{
            laserTimer++;
        }
    }
    
}

